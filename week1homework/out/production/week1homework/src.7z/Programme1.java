public class Programme1 {
    int a = 20;
    int b = 30;
    int c = 40;

    public static void main(String[] args) {
        Programme1 p1 = new Programme1();
        p1.mp();


    }

    public void mp() {
        System.out.println(a*c);
        System.out.println(a*b*c);
        System.out.println(b*c);
        System.out.println(a*b);


    }


}
