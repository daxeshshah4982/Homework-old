public class Programme2 {
static int a = 1000;
static double b = 10.10;
static float c = 50.5f;
static int d = 10;

    public static void main(String[] args){
    div();

    }
    public static void div(){
       System.out.println(a/b);
       System.out.println(a/c);
       System.out.println(b/c);
       System.out.println(a/d);
       System.out.println(b/d);


    }

}
