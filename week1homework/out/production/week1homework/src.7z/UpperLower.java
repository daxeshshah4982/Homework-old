/* Upper case to lower case and vice versa
*/
import com.sun.xml.internal.ws.util.StringUtils;

public class UpperLower {
    public static void main(String[] args){
        String str1 = "MY NAME IS DAXESH";
        System.out.println(str1);
        System.out.println(str1.toLowerCase());

        String str2 = "i like java classes";
        System.out.println(str2);
        System.out.println(str2.toUpperCase());


    }
}
