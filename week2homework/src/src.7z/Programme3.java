/* compute the specified expression and print the output (25.5 *3.5 -3.5 * 3.5) /(40.5 - 4.5)

 */

public class Programme3 {
    public static void main(String[] args){
        double a;
        a = (25.5 *3.5 - 3.5 * 3.5) /(40.5 - 4.5);
        System.out.println(+a);

    }
}
