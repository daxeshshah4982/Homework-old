public class Pattern {
    public static void main(String[] args){
        System.out.println("    j     a     v     v    a");
        System.out.println("    j    a a     v   v    a a");
        System.out.println(" j  j   aaaaa     v v    aaaaa");
        System.out.println("  jj   a      a    v    a     a");
            }
}
